import { type ReactNode, useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ArrowDownRight, ArrowUpRight, BookOpen, ChevronRight, Code2, Compass, Dumbbell, Film, Gamepad2, GitBranch, Heart, Laptop, MapPin, Menu, Music2, NotebookPen, Quote, Sparkles, Terminal, X } from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

const navItems = [
  { id: 'home', label: 'Home' },
  { id: 'who', label: 'Who is Anis' },
  { id: 'world', label: 'The world' },
  { id: 'notes', label: 'Notes' },
  { id: 'future', label: 'My goals' },
];

const notes = [
  { title: 'The desk', tag: 'ritual', text: 'Windows open. VS Code ready. Git clean. Start before the mood arrives.', icon: Laptop, color: 'green' },
  { title: 'The long game', tag: 'direction', text: 'Learn enough to become independent. Build something that has my name on it.', icon: Compass, color: 'red' },
  { title: 'A quiet promise', tag: 'home', text: 'Graduate L3. Find good work. Make my parents proud. Keep going.', icon: Heart, color: 'sand' },
];

const disciplines = [
  { icon: Code2, title: 'The learning stack', detail: 'Eight tools, languages, and directions.' },
  { icon: Terminal, title: 'The problem', detail: 'Computer Science · logic · building' },
  { icon: GitBranch, title: 'The toolkit', detail: 'Practice · patience · showing up' },
];

const learningStack = ['C / C++', 'Python', 'Web Development', 'AI', 'Discord Bots', 'Windows', 'VS Code', 'Git'];

const otherSide = [
  { label: 'Gaming', icon: Gamepad2 },
  { label: 'Gym', icon: Dumbbell },
  { label: 'Movies', icon: Film },
  { label: 'TV shows', icon: Laptop },
  { label: 'Music', icon: Music2 },
  { label: 'Travel', icon: MapPin },
  { label: 'Quiet time', icon: BookOpen },
  { label: 'Friends / family', icon: Heart },
];

const goals = [
  ['Graduate L3', 'The next page'],
  ['Get a good job', 'Build independence'],
  ['Financial freedom', 'Make room to choose'],
  ['Make my parents proud', 'The reason underneath'],
  ['Travel the world', 'See beyond here'],
  ['Build something of my own', 'The long horizon'],
  ['Be the best version of myself', 'Keep becoming'],
];

const principles = ['Muslim First', 'Discipline Builds Freedom', 'Big Dreams, Small Steps', 'Better Days Ahead', 'Good Things Take Time'];

const world = [
  { icon: Music2, label: 'Soundtrack', value: 'Hip-hop / Eminem', note: 'For the days that need a little more weight.' },
  { icon: Gamepad2, label: 'After hours', value: 'PlayStation / PC', note: 'A different kind of focus.' },
  { icon: Dumbbell, label: 'Body', value: 'The gym', note: 'Discipline is also physical.' },
  { icon: BookOpen, label: 'Off-screen', value: 'Books / films', note: 'Breaking Bad, Better Call Saul, The Sopranos, Friends, Shutter Island.' },
];

function useReveals() {
  useEffect(() => {
    const elements = document.querySelectorAll<HTMLElement>('.reveal');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);
}

function DiscMark() {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute -right-3 -top-8 hidden h-28 w-28 rounded-full border border-[#628a6a]/30 sm:block">
      <div className="absolute inset-3 rounded-full border border-[#a33e49]/35" />
      <div className="absolute inset-[2.7rem] rounded-full bg-[#a33e49]/45" />
      <div className="absolute left-1/2 top-1/2 h-px w-16 origin-left -translate-y-1/2 rotate-[28deg] bg-[#628a6a]/50" />
    </div>
  );
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeNote, setActiveNote] = useState<(typeof notes)[number] | null>(null);
  const [thoughtIndex, setThoughtIndex] = useState(0);
  const [focusMode, setFocusMode] = useState(false);
  const firstLoad = useRef(true);
  useReveals();

  useEffect(() => {
    document.title = 'Anis — somewhere between here and what comes next';
    const description = 'A personal corner of the internet for Anis, an Algerian Computer Science student from Jijel.';
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', description);
    const theme = document.querySelector('meta[name="theme-color"]') ?? document.createElement('meta');
    theme.setAttribute('name', 'theme-color');
    theme.setAttribute('content', '#211e19');
    if (!theme.parentNode) document.head.appendChild(theme);
    if (firstLoad.current) {
      firstLoad.current = false;
      window.history.scrollRestoration = 'manual';
    }
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  const thoughts = [
    'Make the next honest move.',
    'A small system beats a loud intention.',
    'Keep the door open for the thing you have not built yet.',
    'Work quietly. Let the future make the noise.',
  ];

  return (
    <main className="page-shell min-h-[100dvh] bg-[#211e19] text-[#e2dccd] selection:bg-[#a33e49] selection:text-[#f2ecde]">
      <header className="fixed top-0 z-30 w-full border-b border-[#d2c7b1]/10 bg-[#211e19]/90 backdrop-blur-sm">
        <div className="mx-auto flex h-[72px] max-w-[1280px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <button data-testid="button-brand-home" onClick={() => scrollTo('home')} className="group flex items-center gap-3 text-left">
            <span className="flex h-8 w-8 items-center justify-center border border-[#628a6a]/70 text-sm font-display italic text-[#c7d3bd] transition-transform group-hover:-rotate-6">A</span>
            <span className="hidden text-[11px] uppercase tracking-[.26em] text-[#b4ab9a] sm:block">an ordinary world / 01</span>
          </button>
          <nav className="hidden items-center gap-7 md:flex" aria-label="Primary navigation">
            {navItems.map((item, index) => (
              <button data-testid={`button-nav-${item.id}`} key={item.id} onClick={() => scrollTo(item.id)} className="ink-link font-mono-ui text-[10px] uppercase tracking-[.2em] text-[#a8a093] hover:text-[#d8d0c0]">
                <span className="mr-2 text-[#628a6a]">0{index + 1}</span>{item.label}
              </button>
            ))}
          </nav>
          <button data-testid="button-menu" onClick={() => setMenuOpen((open) => !open)} className="border border-[#d2c7b1]/20 p-2 text-[#c9c0af] hover:border-[#628a6a] md:hidden" aria-label="Open navigation">
            {menuOpen ? <X size={17} /> : <Menu size={17} />}
          </button>
        </div>
        {menuOpen && (
          <div className="border-t border-[#d2c7b1]/10 bg-[#25211c] px-5 py-5 md:hidden">
            <div className="flex flex-col gap-4">
              {navItems.map((item, index) => (
                <button data-testid={`button-mobile-nav-${item.id}`} key={item.id} onClick={() => scrollTo(item.id)} className="flex items-center gap-4 text-left font-mono-ui text-[11px] uppercase tracking-[.2em] text-[#b5ad9e]">
                  <span className="text-[#a33e49]">0{index + 1}</span>{item.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </header>

      <section id="home" className="relative mx-auto flex min-h-[min(900px,100dvh)] max-w-[1280px] items-end px-5 pb-20 pt-36 sm:px-8 lg:px-12 lg:pb-28">
        <div className="ambient-orb pointer-events-none absolute right-[4%] top-[20%] h-40 w-40 rounded-full bg-[#4a7b56]/10 blur-3xl" />
        <div className="pointer-events-none absolute right-6 top-32 hidden h-56 border-l border-[#d2c7b1]/15 lg:block">
          <p className="vertical-label ml-3 font-mono-ui text-[9px] uppercase tracking-[.32em] text-[#7d776c]">Jijel / Algeria / 2024—</p>
        </div>
        <div className="relative w-full">
          <div className="reveal mb-10 flex items-center gap-3">
            <span className="h-px w-9 bg-[#a33e49]" />
            <span className="font-mono-ui text-[10px] uppercase tracking-[.28em] text-[#a8a093]">a personal index</span>
          </div>
          <h1 className="reveal reveal-delay-1 max-w-[920px] font-display text-[clamp(4.6rem,13vw,11.8rem)] leading-[.77] tracking-[-.055em] text-[#e7dfd0]">
            Anis<span className="text-[#a33e49]">.</span>
          </h1>
          <div className="reveal reveal-delay-2 mt-10 flex max-w-[720px] flex-col gap-8 sm:flex-row sm:items-end sm:justify-between">
            <p className="max-w-[470px] font-display text-[clamp(1.55rem,3vw,2.65rem)] leading-[.98] text-[#bdb3a2]">
              Somewhere between <em className="text-[#d8cfbe]">here</em> and what comes next.
            </p>
            <div className="max-w-[220px] border-l border-[#628a6a]/60 pl-4">
              <p className="font-mono-ui text-[10px] uppercase leading-[1.6] tracking-[.15em] text-[#8f897e]">Computer Science student / Jijel, Algeria</p>
            </div>
          </div>
          <div className="reveal reveal-delay-3 mt-16 flex flex-wrap items-center gap-x-8 gap-y-4">
            <button data-testid="button-enter-world" onClick={() => scrollTo('world')} className="group flex items-center gap-4 border border-[#d2c7b1]/25 px-5 py-3 font-mono-ui text-[10px] uppercase tracking-[.18em] text-[#d8d0c1] transition-colors hover:border-[#628a6a] hover:bg-[#628a6a]/10">
              Enter the world <ArrowDownRight size={15} className="transition-transform group-hover:translate-x-1 group-hover:translate-y-1" />
            </button>
            <span className="font-display text-lg italic text-[#817a6f]">No résumé energy here.</span>
          </div>
        </div>
        <div className="absolute bottom-8 right-5 hidden items-center gap-3 lg:flex">
          <span className="font-mono-ui text-[9px] uppercase tracking-[.24em] text-[#68635a]">scroll to look around</span>
          <ArrowDownRight size={14} className="text-[#628a6a]" />
        </div>
      </section>

      <section id="who" className="border-y border-[#d2c7b1]/10 bg-[#24211c]">
        <div className="mx-auto grid max-w-[1280px] grid-cols-1 gap-16 px-5 py-24 sm:px-8 lg:grid-cols-[.82fr_1.18fr] lg:gap-24 lg:px-12 lg:py-32">
          <div className="reveal">
            <span className="font-mono-ui text-[10px] uppercase tracking-[.26em] text-[#628a6a]">01 — Who is Anis</span>
            <h2 className="mt-6 max-w-[400px] font-display text-[clamp(3.4rem,7vw,6.5rem)] leading-[.82] tracking-[-.045em] text-[#e2dacb]">A person,<br /><em className="text-[#a33e49]">in progress.</em></h2>
            <p className="mt-9 max-w-[370px] text-sm leading-[1.85] text-[#aca293]">
              Anis is a Computer Science student — Informatique — from Jijel, Algeria. He is interested in technology, music, gaming, fitness, creativity, and the patient work of building his own future.
            </p>
            <div className="mt-10 flex items-center gap-3">
              <span className="h-px w-8 bg-[#a33e49]" />
              <span className="font-display text-lg italic text-[#8f877a]">Still figuring it out. Still showing up.</span>
            </div>
          </div>
          <div className="reveal reveal-delay-1">
            <div className="mb-6 flex items-end justify-between border-b border-[#d2c7b1]/15 pb-5">
              <div>
                <span className="font-mono-ui text-[10px] uppercase tracking-[.24em] text-[#a8a093]">The learning stack</span>
                <p className="mt-2 text-xs text-[#777168]">The things currently worth sitting down with.</p>
              </div>
              <span className="font-mono-ui text-[10px] text-[#a33e49]">08 / 08</span>
            </div>
            <div className="grid grid-cols-1 border-l border-[#628a6a]/60 sm:grid-cols-2">
              {learningStack.map((item, index) => (
                <div data-testid={`text-learning-stack-${index}`} key={item} className="group flex items-center gap-4 border-b border-[#d2c7b1]/12 px-5 py-5 transition-colors hover:bg-[#2d2922]">
                  <span className="font-mono-ui text-[9px] text-[#a33e49]">0{index + 1}</span>
                  <span className="font-display text-[1.45rem] text-[#d2c9b9] transition-colors group-hover:text-[#aec2ac]">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="world" className="relative border-y border-[#d2c7b1]/10 bg-[#29251f]">
        <div className="mx-auto grid max-w-[1280px] grid-cols-1 gap-12 px-5 py-24 sm:px-8 lg:grid-cols-[.72fr_1.28fr] lg:gap-24 lg:px-12 lg:py-32">
          <div className="reveal">
            <span className="font-mono-ui text-[10px] uppercase tracking-[.26em] text-[#628a6a]">01 — The world</span>
            <h2 className="mt-7 max-w-[430px] font-display text-[clamp(3.3rem,7vw,6.7rem)] leading-[.85] tracking-[-.04em] text-[#e2dacb]">The things<br /><em className="text-[#a33e49]">that stay.</em></h2>
            <p className="mt-9 max-w-[340px] text-sm leading-[1.8] text-[#a9a093]">A few coordinates. The subjects, sounds and rituals that make the days feel like mine.</p>
            <div className="mt-12 flex items-center gap-3">
              <MapPin size={15} className="text-[#a33e49]" />
              <span className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-[#aaa193]">Jijel, Algeria</span>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-px border border-[#d2c7b1]/12 bg-[#d2c7b1]/12 sm:grid-cols-2">
            {world.map((item, index) => {
              const Icon = item.icon;
              return (
                <article data-testid={`card-world-${index}`} key={item.label} className="reveal group relative min-h-[205px] bg-[#29251f] p-6 transition-colors hover:bg-[#332e26] sm:p-8" style={{ transitionDelay: `${index * 70}ms` }}>
                  <Icon size={19} strokeWidth={1.3} className="text-[#628a6a] transition-transform group-hover:-translate-y-1" />
                  <div className="mt-12">
                    <p className="font-mono-ui text-[9px] uppercase tracking-[.22em] text-[#797268]">{item.label}</p>
                    <h3 className="mt-2 font-display text-2xl text-[#d9d0c0]">{item.value}</h3>
                    <p className="mt-3 max-w-[230px] text-xs leading-relaxed text-[#958d81]">{item.note}</p>
                  </div>
                  <span className="absolute right-5 top-5 font-mono-ui text-[9px] text-[#6e685e]">0{index + 1}</span>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <section id="soundtrack" className="relative border-b border-[#d2c7b1]/10 bg-[#1f1c18]">
        <div className="mx-auto grid max-w-[1280px] grid-cols-1 gap-12 px-5 py-24 sm:px-8 lg:grid-cols-[.8fr_1.2fr] lg:items-center lg:gap-24 lg:px-12 lg:py-32">
          <div className="reveal">
            <span className="font-mono-ui text-[10px] uppercase tracking-[.26em] text-[#628a6a]">02 — My Soundtrack</span>
            <div className="mt-8 flex items-center gap-4">
              <span className="flex h-12 w-12 items-center justify-center border border-[#a33e49]/70 text-[#c15b64]"><Music2 size={21} strokeWidth={1.25} /></span>
              <div>
                <p className="font-mono-ui text-[9px] uppercase tracking-[.2em] text-[#80786c]">in rotation</p>
                <p className="mt-1 font-display text-2xl text-[#d8cfbf]">Eminem / hip-hop</p>
              </div>
            </div>
          </div>
          <div className="reveal reveal-delay-1 relative border-l border-[#a33e49]/70 pl-7 sm:pl-12">
            <DiscMark />
            <p className="relative z-[1] max-w-[680px] font-display text-[clamp(2.5rem,6vw,6rem)] leading-[.86] tracking-[-.04em] text-[#e2dacd]">Real hip hop. Real lyrics. Real shit.</p>
            <p className="relative z-[1] mt-8 max-w-[360px] text-sm leading-[1.8] text-[#91887b]">No player here. Just the part of the soundtrack that belongs in the room while the work gets done.</p>
          </div>
        </div>
      </section>

      <section id="places" className="border-b border-[#d2c7b1]/10 bg-[#29251f]">
        <div className="mx-auto max-w-[1280px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
          <div className="reveal flex flex-col justify-between gap-7 sm:flex-row sm:items-end">
            <div>
              <span className="font-mono-ui text-[10px] uppercase tracking-[.26em] text-[#628a6a]">03 — Places</span>
              <h2 className="mt-6 font-display text-[clamp(3.6rem,8vw,8rem)] leading-[.79] tracking-[-.05em] text-[#e1d9c9]">Start<br /><em className="text-[#a33e49]">here.</em></h2>
            </div>
            <p className="max-w-[290px] font-display text-2xl leading-[.98] text-[#aaa091]">A map with more blank space than pins.</p>
          </div>
          <div className="reveal relative mt-20 overflow-hidden border border-[#d2c7b1]/20 bg-[#24211c] px-5 py-12 sm:px-12 sm:py-16">
            <div className="pointer-events-none absolute inset-x-0 top-1/2 border-t border-dashed border-[#628a6a]/35" />
            <div className="pointer-events-none absolute bottom-0 left-[26%] top-0 border-l border-dashed border-[#d2c7b1]/10" />
            <div className="pointer-events-none absolute bottom-0 left-[68%] top-0 border-l border-dashed border-[#d2c7b1]/10" />
            <div className="relative z-[1] flex flex-col justify-between gap-10 sm:flex-row sm:items-center">
              {['Jijel', 'Alger', 'The World'].map((place, index) => (
                <div data-testid={`place-${index}`} key={place} className={`flex items-center gap-4 ${index === 1 ? 'sm:flex-col sm:gap-3' : 'sm:flex-col sm:gap-3'} ${index === 1 ? 'sm:translate-y-8' : ''}`}>
                  <span className={`flex h-10 w-10 items-center justify-center rounded-full border ${index === 0 ? 'border-[#a33e49] bg-[#a33e49]/15' : 'border-[#628a6a]/70 bg-[#628a6a]/10'}`}>
                    <MapPin size={15} className={index === 0 ? 'text-[#ce7077]' : 'text-[#91ad91]'} />
                  </span>
                  <div className="sm:text-center">
                    <p className="font-display text-3xl text-[#dcd3c3]">{place}</p>
                    {index === 0 && <p className="mt-1 font-mono-ui text-[9px] uppercase tracking-[.2em] text-[#a33e49]">starting point</p>}
                  </div>
                </div>
              ))}
            </div>
            <div className="relative z-[1] mt-10 border-t border-[#d2c7b1]/15 pt-7 text-center sm:mt-14">
              <p data-testid="text-journey" className="font-mono-ui text-[clamp(1rem,2.5vw,1.8rem)] uppercase tracking-[.2em] text-[#bdb3a3]">Jijel → Alger → The World</p>
            </div>
          </div>
        </div>
      </section>

      <section id="other-side" className="mx-auto max-w-[1280px] px-5 py-24 sm:px-8 lg:px-12 lg:py-32">
        <div className="reveal flex flex-col justify-between gap-8 border-b border-[#d2c7b1]/12 pb-8 lg:flex-row lg:items-end">
          <div>
            <span className="font-mono-ui text-[10px] uppercase tracking-[.26em] text-[#628a6a]">04 — The Other Side</span>
            <h2 className="mt-6 font-display text-[clamp(3.4rem,7vw,7rem)] leading-[.8] tracking-[-.045em] text-[#e1d9c9]">Off the<br /><em className="text-[#a33e49]">clock.</em></h2>
          </div>
          <p className="max-w-[320px] text-sm leading-[1.8] text-[#a39a8c]">There is more to a person than what they study. These are the places the day loosens its grip.</p>
        </div>
        <div className="mt-14 grid grid-cols-2 border-l border-t border-[#d2c7b1]/15 sm:grid-cols-4">
          {otherSide.map((item, index) => {
            const Icon = item.icon;
            return (
              <div data-testid={`card-other-side-${index}`} key={item.label} className="reveal group min-h-[130px] border-b border-r border-[#d2c7b1]/15 p-5 transition-colors hover:bg-[#29251f] sm:min-h-[160px] sm:p-7">
                <Icon size={18} strokeWidth={1.25} className="text-[#628a6a] transition-transform group-hover:-translate-y-1" />
                <p className="mt-9 font-display text-xl text-[#d5ccbd]">{item.label}</p>
              </div>
            );
          })}
        </div>
        <div className="reveal mt-8 flex flex-col gap-3 border-l-2 border-[#a33e49]/70 pl-5">
          <span className="font-mono-ui text-[9px] uppercase tracking-[.2em] text-[#82796e]">On the screen</span>
          <p className="font-display text-2xl text-[#b9af9f]">Breaking Bad · Better Call Saul · The Sopranos · Friends · Shutter Island</p>
        </div>
      </section>

      <section id="notes" className="mx-auto max-w-[1280px] px-5 py-24 sm:px-8 lg:px-12 lg:py-36">
        <div className="reveal flex flex-col justify-between gap-7 border-b border-[#d2c7b1]/12 pb-8 sm:flex-row sm:items-end">
          <div>
            <span className="font-mono-ui text-[10px] uppercase tracking-[.26em] text-[#628a6a]">02 — Notebook pages</span>
            <h2 className="mt-5 font-display text-[clamp(3.4rem,7vw,7rem)] leading-[.82] tracking-[-.04em] text-[#e3dbcc]">Things I<br /><em className="text-[#a33e49]">keep close.</em></h2>
          </div>
          <div className="flex items-center gap-4 pb-2">
            <NotebookPen size={18} className="text-[#c3b8a5]" />
            <p className="max-w-[175px] font-display text-lg leading-none text-[#938b7e]">Not a list. More like a trail of evidence.</p>
          </div>
        </div>
        <div className="mt-16 grid gap-12 md:grid-cols-3 md:gap-8">
          {notes.map((note, index) => {
            const Icon = note.icon;
            return (
              <button data-testid={`button-note-${index}`} key={note.title} onClick={() => setActiveNote(note)} style={{ transform: `rotate(${index === 1 ? 1.4 : -1.2}deg)` }} className={`paper-card reveal reveal-delay-${index + 1} group relative min-h-[300px] p-7 text-left transition-transform hover:-translate-y-2 hover:rotate-0`}>
                <span className="tape" />
                <div className="relative z-[1] flex h-full flex-col justify-between">
                  <div className="flex items-start justify-between">
                    <span className="font-mono-ui text-[9px] uppercase tracking-[.2em] opacity-60">{note.tag}</span>
                    <Icon size={18} strokeWidth={1.5} className={note.color === 'red' ? 'text-[#9d3e49]' : note.color === 'green' ? 'text-[#487151]' : 'text-[#907a58]'} />
                  </div>
                  <div>
                    <h3 className="font-display text-[2.7rem] leading-none">{note.title}</h3>
                    <p className="mt-5 max-w-[255px] text-sm leading-[1.55] opacity-75">{note.text}</p>
                    <span className="mt-7 inline-flex items-center gap-2 font-mono-ui text-[9px] uppercase tracking-[.18em] opacity-55 transition-opacity group-hover:opacity-100">Open page <ArrowUpRight size={12} /></span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
        <div className="reveal mt-16 flex flex-col items-start justify-between gap-6 border-t border-[#d2c7b1]/12 pt-7 sm:flex-row sm:items-center">
          <div className="flex items-center gap-3">
            <span className="h-2 w-2 rounded-full bg-[#628a6a]" />
            <span className="font-mono-ui text-[10px] uppercase tracking-[.18em] text-[#938a7b]">A thought from the margins</span>
          </div>
          <p data-testid="text-random-thought" className="font-display text-2xl italic text-[#c2b7a6]">“{thoughts[thoughtIndex]}”</p>
          <button data-testid="button-shuffle-thought" onClick={() => setThoughtIndex((index) => (index + 1) % thoughts.length)} className="flex items-center gap-2 border-b border-[#a33e49]/70 pb-1 font-mono-ui text-[9px] uppercase tracking-[.19em] text-[#b76068] hover:text-[#d07b81]">
            Turn the page <ChevronRight size={13} />
          </button>
        </div>
      </section>

      <section className="border-y border-[#d2c7b1]/10 bg-[#24211c]">
        <div className="mx-auto grid max-w-[1280px] grid-cols-1 gap-16 px-5 py-24 sm:px-8 lg:grid-cols-[.9fr_1.1fr] lg:gap-28 lg:px-12 lg:py-32">
          <div className="reveal">
            <span className="font-mono-ui text-[10px] uppercase tracking-[.26em] text-[#628a6a]">03 — How I spend the hours</span>
            <div className="mt-10 flex items-start gap-5">
              <div className="mt-2 h-10 w-px bg-[#a33e49]" />
              <div>
                <h2 className="font-display text-[clamp(3.1rem,6vw,6rem)] leading-[.86] tracking-[-.04em] text-[#dfd7c8]">Learn.<br />Build.<br /><em className="text-[#628a6a]">Repeat.</em></h2>
                <p className="mt-9 max-w-[310px] text-sm leading-[1.8] text-[#a69c8e]">Not chasing the appearance of progress. Just trying to get a little more capable than yesterday.</p>
              </div>
            </div>
          </div>
          <div className="grid gap-0 border-t border-[#d2c7b1]/15">
            {disciplines.map((item, index) => {
              const Icon = item.icon;
              return (
                <div data-testid={`row-discipline-${index}`} key={item.title} className="reveal group flex items-center gap-5 border-b border-[#d2c7b1]/15 py-7" style={{ transitionDelay: `${index * 90}ms` }}>
                  <span className="font-mono-ui text-[10px] text-[#a33e49]">0{index + 1}</span>
                  <Icon size={21} strokeWidth={1.25} className="text-[#8d9f88]" />
                  <div className="flex-1">
                    <h3 className="font-display text-2xl text-[#d6cebf]">{item.title}</h3>
                    <p className="mt-1 font-mono-ui text-[10px] uppercase tracking-[.12em] text-[#81796e]">{item.detail}</p>
                  </div>
                  <ArrowUpRight size={15} className="text-[#716b62] transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section id="future" className="relative mx-auto max-w-[1280px] px-5 py-24 sm:px-8 lg:px-12 lg:py-36">
        <div className="ambient-orb pointer-events-none absolute left-[10%] top-28 h-24 w-24 rounded-full bg-[#a33e49]/10 blur-3xl" />
        <div className="reveal grid gap-14 lg:grid-cols-[1.1fr_.9fr] lg:items-end">
          <div>
            <span className="font-mono-ui text-[10px] uppercase tracking-[.26em] text-[#628a6a]">07 — My Goals</span>
            <h2 className="mt-6 max-w-[780px] font-display text-[clamp(4rem,9vw,9rem)] leading-[.77] tracking-[-.055em] text-[#e4dccd]">Make room<br />for <em className="text-[#a33e49]">more.</em></h2>
          </div>
          <div className="lg:pb-2">
            <Quote size={25} strokeWidth={1} className="mb-4 text-[#628a6a]" />
            <p className="max-w-[330px] font-display text-[1.65rem] leading-[1.03] text-[#b8ad9c]">The plan is simple enough to remember, difficult enough to matter.</p>
          </div>
        </div>
        <div className="reveal mt-20 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {goals.map(([title, detail], index) => (
            <div data-testid={`card-goal-${index}`} key={title} className="group border-l border-[#d2c7b1]/20 py-2 pl-5 transition-colors hover:border-[#a33e49]">
              <span className="font-mono-ui text-[9px] uppercase tracking-[.22em] text-[#81796e]">{String(index + 1).padStart(2, '0')}</span>
              <h3 className="mt-7 font-display text-[1.5rem] leading-none text-[#d7cebd]">{title}</h3>
              <p className="mt-3 text-xs text-[#8e867a]">{detail}</p>
            </div>
          ))}
        </div>
        <div className="reveal mt-20 flex flex-col items-start justify-between gap-8 border-t border-[#d2c7b1]/12 pt-8 md:flex-row md:items-center">
          <div>
            <span className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-[#8c8478]">A small personal switch</span>
            <p className="mt-2 font-display text-xl text-[#c9bfae]">{focusMode ? 'Focus mode: one thing, properly.' : 'Tap it when the day needs a clean edge.'}</p>
          </div>
          <button data-testid="button-focus-mode" onClick={() => setFocusMode((active) => !active)} className={`flex items-center gap-4 border px-5 py-3 font-mono-ui text-[10px] uppercase tracking-[.18em] transition-colors ${focusMode ? 'border-[#628a6a] bg-[#628a6a]/15 text-[#c0d0bd]' : 'border-[#d2c7b1]/25 text-[#b9b0a1] hover:border-[#628a6a]'}`}>
            <span className={`h-2 w-2 rounded-full ${focusMode ? 'bg-[#8eb092]' : 'bg-[#a33e49]'}`} />
            {focusMode ? 'Focus is on' : 'Set the tone'}
          </button>
        </div>
      </section>

      <section id="principles" className="border-y border-[#d2c7b1]/10 bg-[#24211c]">
        <div className="mx-auto max-w-[1280px] px-5 py-20 sm:px-8 lg:px-12 lg:py-28">
          <div className="reveal flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <span className="font-mono-ui text-[10px] uppercase tracking-[.26em] text-[#628a6a]">08 — My Principles</span>
              <h2 className="mt-5 font-display text-[clamp(3rem,6vw,6rem)] leading-[.82] tracking-[-.04em] text-[#ded6c7]">Keep it<br /><em className="text-[#a33e49]">simple.</em></h2>
            </div>
            <p className="max-w-[290px] font-display text-xl leading-[1.05] text-[#a69d8e]">A few quiet sentences to come back to.</p>
          </div>
          <div className="reveal mt-14 grid border-l border-t border-[#d2c7b1]/15 sm:grid-cols-2 lg:grid-cols-3">
            {principles.map((principle, index) => (
              <div data-testid={`text-principle-${index}`} key={principle} className="flex min-h-[100px] items-center gap-4 border-b border-r border-[#d2c7b1]/15 px-5 py-6 sm:px-7">
                <span className="font-mono-ui text-[9px] text-[#a33e49]">0{index + 1}</span>
                <p className="font-display text-[1.35rem] text-[#cfc6b7]">{principle}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-[#d2c7b1]/10 bg-[#1c1a17]">
        <div className="mx-auto flex max-w-[1280px] flex-col gap-10 px-5 py-14 sm:px-8 md:flex-row md:items-end md:justify-between lg:px-12">
          <div>
            <div className="flex items-center gap-3">
              <span className="flex h-8 w-8 items-center justify-center border border-[#a33e49]/70 font-display italic text-[#c8bdae]">A</span>
              <span className="font-display text-2xl text-[#d1c7b6]">Keep going.</span>
            </div>
            <p className="mt-5 max-w-[280px] text-xs leading-[1.7] text-[#777168]">A small corner of the internet, kept by Anis from Jijel.</p>
          </div>
          <div className="flex flex-col items-start gap-3 md:items-end">
            <span className="stamp px-3 py-2 font-mono-ui text-[9px] uppercase tracking-[.18em]">Still becoming</span>
            <p className="font-mono-ui text-[9px] uppercase tracking-[.18em] text-[#676159]">© Anis / no finished version</p>
          </div>
        </div>
      </footer>

      {activeNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#120f0d]/80 p-5 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={activeNote.title}>
          <div className="paper-card relative w-full max-w-[460px] p-8 sm:p-11">
            <span className="tape" />
            <button data-testid="button-close-note" onClick={() => setActiveNote(null)} className="absolute right-5 top-5 p-2 opacity-60 hover:opacity-100" aria-label="Close note"><X size={17} /></button>
            <div className="relative z-[1]">
              <span className="font-mono-ui text-[9px] uppercase tracking-[.2em] opacity-60">{activeNote.tag} / page open</span>
              <h2 className="mt-12 font-display text-5xl leading-none">{activeNote.title}</h2>
              <p className="mt-7 font-display text-2xl leading-[1.1] text-[#514b41]">{activeNote.text}</p>
              <div className="mt-12 flex items-center gap-2 border-t border-[#6c6253]/25 pt-5 font-mono-ui text-[9px] uppercase tracking-[.18em] opacity-60"><Sparkles size={13} /> written somewhere between work and rest</div>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;