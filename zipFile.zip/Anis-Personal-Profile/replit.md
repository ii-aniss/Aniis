# Anis — Personal Profile

A cinematic, interactive personal identity website for Anis, an Algerian Computer Science student from Jijel.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/anis-profile run dev` — run the personal profile site
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/anis-profile/src/App.tsx` — the page content, interactions, and static profile data
- `artifacts/anis-profile/src/index.css` — the visual system, typography, textures, motion, and responsive rules
- `vercel.json` — root-level Vercel build and output configuration
- `screenshots/anis-profile-final.jpg` — latest verified preview capture

## Architecture decisions

- The profile is frontend-only and static; no backend, database, audio embed, or personal data service is needed.
- The page uses local static content so it can be pushed to GitHub and built directly by Vercel.
- Replit workflow variables remain supported, but Vite defaults to standard values so Vercel can run the same build command.

## Product

- Long-form personal identity page with smooth anchor navigation
- Interactive paper notes with modal detail views
- Thought shuffle and focus-mode micro-interactions
- Sections for Anis's world, learning stack, soundtrack, places, other interests, goals, and principles

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
